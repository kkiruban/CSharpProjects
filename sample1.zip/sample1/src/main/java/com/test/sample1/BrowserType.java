package com.test.sample1;

public enum BrowserType {
	CHROME,
	FIREFOX,
	IE,
	SAFARI;
}
