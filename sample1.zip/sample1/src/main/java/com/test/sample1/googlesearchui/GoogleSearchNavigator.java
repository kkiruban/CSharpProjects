package com.test.sample1.googlesearchui;

import org.openqa.selenium.WebDriver;

public interface GoogleSearchNavigator {

	public boolean validateHomePage(WebDriver driver) throws Exception ;
}
