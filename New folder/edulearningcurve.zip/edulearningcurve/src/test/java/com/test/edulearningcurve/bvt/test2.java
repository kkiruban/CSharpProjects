package com.test.edulearningcurve.bvt;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;

import com.test.edulearningcurve.Config;


public class test2 {
@Test(enabled = true)
public void test1() throws InterruptedException {
	
	System.setProperty("webdriver.edge.driver", "D:\\Workspace\\edulearningcurve\\src\\test\\resources\\MicrosoftWebDriver.exe");
	WebDriver driver= new EdgeDriver();
//	System.setProperty("webdriver.ie.driver", "D:\\Workspace\\edulearningcurve\\src\\test\\resources\\IEDriverServer.exe");
//	WebDriver driver= new InternetExplorerDriver();
//	System.setProperty("webdriver.chrome.driver", "D:\\Workspace\\edulearningcurve\\src\\test\\resources\\chromedriver.exe");
//	WebDriver driver = new ChromeDriver();
//	System.setProperty("webdriver.gecko.driver","D:\\Workspace\\edulearningcurve\\src\\test\\resources\\geckodriver.exe");
//	WebDriver driver = new FirefoxDriver();
	driver.get("https://www.google.co.in");
//	driver.manage().window().maximize();
	driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
//	Thread.sleep(10000);
	
	String title = driver.getTitle();
	System.out.println("Title :"+title);
	if(title.equals("Google")){
		System.out.println("Test Passed");
	}else{
		System.out.println("Test Failed");
	}
	boolean elementIsDisplayed = driver.findElement(By.id("hplogo")).isDisplayed();
	System.out.println("Element is present : "+elementIsDisplayed);
	
	boolean elementIsEnabled = driver.findElement(By.id("hplogo")).isEnabled();
	System.out.println("Element is enabled : "+elementIsEnabled);
	driver.quit();
	
}
}
