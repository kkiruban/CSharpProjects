package com.test.edulearningcurve.bvt;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.test.edulearningcurve.BaseTest;

public class test extends BaseTest{
	public test() {
		logger = Logger.getLogger(this.getClass());
	}
@Test(enabled = false)
public void test1() throws InterruptedException{
	Thread.sleep(15000);
	Assert.assertTrue(elcNavigator.validateHomePage(), "Not validated home page.");
	logger.info("Test is executed successfully.");
}
@Test(enabled = true)
public void test2() throws InterruptedException{
//	Thread.sleep(15000);
	
	
	Assert.assertTrue(elcNavigator.validateHomePage(), "Not validated home page.");
	logger.info("Test is executed successfully.");
}
}
