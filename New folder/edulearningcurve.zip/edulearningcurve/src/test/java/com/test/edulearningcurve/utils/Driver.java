package com.test.edulearningcurve.utils;

import java.util.Hashtable;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

import com.test.edulearningcurve.Config;

public class Driver {

	public static WebDriver driver = browserFactory();
	//public static WebDriver driver = new ChromeDriver();
	
	public static WebDriver browserFactory(){
		//System.setProperty("webdriver.gecko.driver","G:\\eclipse-workspace\\zeeui\\driver\\geckodriver.exe");
		String browserType=Config.getValue("BROWSER_TYPE");
		if(browserType.equals("firefox")){
			System.setProperty("webdriver.gecko.driver",Config.getValue("GECKO_DRIVER"));
			FirefoxProfile profile = new FirefoxProfile();
			profile.setPreference("browser.download.folderList",2);
			profile.setPreference("browser.download.manager.showWhenStarting",false);
			profile.setPreference("browser.download.dir",Config.getValue("EXPORT_FILE_PATH"));
			profile.setPreference("browser.helperApps.neverAsk.saveToDisk","image/jpg, text/csv,text/xml,application/xml,application/vnd.ms-excel,application/x-excel,application/x-msexcel,application/excel,application/pdf,application/octet-stream");
			driver=new FirefoxDriver(profile);
		}else if(browserType.equals("chrome")){
			System.setProperty("webdriver.chrome.driver", Config.getValue("CHROME_DRIVER"));
			Map<String, String> prefs = new Hashtable<String, String>();
			prefs.put("download.prompt_for_download", "false");
			prefs.put("download.default_directory", Config.getValue("EXPORT_FILE_PATH"));
			//prefs.put("download.extensions_to_open", "image/jpg, text/csv,text/xml,application/xml,application/vnd.ms-excel,application/x-excel,application/x-msexcel,application/excel,application/pdf");
			prefs.put("download.extensions_to_open", "image/jpg, text/csv,text/xml,application/xml,application/vnd.ms-excel,application/x-excel,application/x-msexcel,application/excel,application/pdf,application/octet-stream");
			
			ChromeOptions options= new ChromeOptions();
			options.setExperimentalOption("prefs", prefs);
			driver= new ChromeDriver(options);
			
		}
		else if(browserType.equals("ie")){
			System.setProperty("webdriver.ie.driver", Config.getValue("IE_DRIVER"));
			driver= new InternetExplorerDriver();
			
		}else if(browserType.equals("edge")){
			System.setProperty("webdriver.edge.driver", Config.getValue("EDGE_DRIVER"));
			driver= new EdgeDriver();
			
		}else if(browserType.equals("safari")){
			driver= new SafariDriver();
		} else if (browserType.equals("htmlUnit")) {
			driver = new HtmlUnitDriver();
		}
		
		return driver;
		
	}
}
