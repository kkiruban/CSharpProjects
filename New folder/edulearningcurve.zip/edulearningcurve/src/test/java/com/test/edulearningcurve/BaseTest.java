package com.test.edulearningcurve;

import org.apache.log4j.Logger;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.test.edulearningcurve.elcui.ELCNavigator;
import com.test.edulearningcurve.elcui.impl.ELCNavigatorImpl;
import com.test.edulearningcurve.utils.CommonUtil;
import com.test.edulearningcurve.utils.CustomHTMLLayout;
import com.test.edulearningcurve.utils.TestStatusUpdateUtil;



public class BaseTest {
	
	protected static ELCNavigator elcNavigator = null ;
//	
//	protected static JiraNavigator jiraNavigator = null ;
	
	protected static boolean isInit = false ;
	
	/***stores the <b>alt Id</b> of currently running bvt*/
	protected static int altID;
	/***stores boolean value as true or false according to status of current bvt*/
	protected boolean isSuccess = false ;
	
	protected Logger logger = null ;
	
	protected static final boolean testEnabled = true;
	
	
//	protected static ZAPIAPIServiceImpl zapiService = null;
	
	protected static String testcaseId;
	
	protected static String bvtFilePath = null;
	
	public BaseTest(){
		init();
	}
	
	public void init(){
		if(isInit){
			return;
		}
		new Config();
		elcNavigator = new ELCNavigatorImpl();
//		jiraNavigator = new JiraNavigatorFactory().getInstance();
//		zapiService = new ZAPIAPIServiceImpl();
		isInit=true;
	}
	
	
	/**
	 * updates the current bvt status in excel bvt sheet
	 * @param status		default value as <b>f<b>
	 */
	public void updateStatus(){
		String status = "f";
		if(isSuccess){
			status="p";
		}
		TestStatusUpdateUtil.writeStatus(Config.getFilePath("ZE_5.0_BVT_Fayre.xls"), altID, status);
	}
	
	public  void captureScreenshotInLog() {
		CommonUtil.captureScreenshot(Config.getScreenPath());
		String imgPath = CommonUtil.captureScreenshot(Config.getScreenPath());
		logger.info(CustomHTMLLayout.IMAGE_PREFIX + "src=\"../" + imgPath + "\"/>");
	}
	
	@BeforeSuite
	public void beforeSuite(){
//		extentReport = new ExtentReports("reports" + File.separator + "ExtentReportsTestNG.html", true);
//		bvtFilePath = Config.getFilePath("ZE_5.0_BVT_Fayre.xls");
//		TestStatusUpdateUtil.setBuildNumber(bvtFilePath, Config.getValue("BUILD_NO"));
		
		
		CommonUtil.launchBrowser(Config.getValue("ELC_URL"));
		
		/*FileOperations f1=new FileOperations();
		f1.clearDirectory(Config.getValue("DOWNLOAD_PATH"));*/
	}

	@AfterSuite
	  public void afterSuite() {
		  CommonUtil.closeTheDriver();
	  }
		
	 /**
	  * updates the status of current bvt in bvt excel sheet<br>
	  */
	public void baseAfterMethod() {
		if(!isSuccess){
			captureScreenshotInLog();
		}
		if(altID > 0){  
			updateStatus();
		}
	}

	

}
