package com.test.edulearningcurve.elcui.impl;

import com.test.edulearningcurve.elcui.ELCNavigator;
import com.test.edulearningcurve.elcui.impl.pages.ELCHomePage;

public class ELCNavigatorImpl implements ELCNavigator {

	public boolean validateHomePage() {
		return ELCHomePage.getInstance().validateELCHomePage();
	}
	

}
