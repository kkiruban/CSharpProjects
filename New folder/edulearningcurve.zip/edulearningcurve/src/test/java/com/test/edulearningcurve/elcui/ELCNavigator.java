package com.test.edulearningcurve.elcui;

public interface ELCNavigator {

	public boolean validateHomePage();

}
