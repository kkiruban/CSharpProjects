package com.test.edulearningcurve.utils;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileInputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.test.edulearningcurve.Constants;

public class CommonUtil {

	public static Properties loadProperties(String path) {
		Properties properties = new Properties();
		FileInputStream fis = null ;
		try {
			File file = getPropertyFilePath(path); 
			fis = new FileInputStream(file);
			properties.load(fis);
			fis.close();
		} catch (Exception e) {
			return null ;
		} finally {
			if (fis != null) {
				try {
					fis.close();
				} catch (Exception e) {
					;
				}
			}
		}
		return properties ;
	}
	
	public static File getPropertyFilePath(String path) throws URISyntaxException {
        URL url = path.getClass().getResource(path);
	    File inputFile = new File(url.toURI());
	    return inputFile ;
	}
	
	public static boolean launchBrowser(String url){
		try{
			
			Driver.driver.get(url);
//			Driver.driver.manage().window().maximize();
			implicitWait(Constants.EXPLICIT_WAIT_HIGH);
			Thread.sleep(5000);
		}catch(Exception e){
			System.out.println(e);
			return false;
		}
		return true;
	}
	
	public static void moveToElement(WebElement wb){
		Actions action = new Actions(Driver.driver);
		 
        action.moveToElement(wb).build().perform();
	}
	
	public static boolean isElementPresent(String xpath) {
	    try {
	        Driver.driver.findElement(By.xpath(xpath));
	        return true;
	    } catch (Exception e) {
	        return false;
	    }
	}
	
	public static void implicitWait(int timetowaitInSec){
		Driver.driver.manage().timeouts().implicitlyWait(timetowaitInSec, TimeUnit.SECONDS);
	}
	
	public static void ExplicitWaitForElement(WebElement element){
		try{
			WebDriverWait wb=new WebDriverWait(Driver.driver, Constants.EXPLICIT_WAIT_HIGH);
			wb.until(ExpectedConditions.visibilityOf(element));
			
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void isElementClickable(WebElement element){
		try{
			WebDriverWait wb=new WebDriverWait(Driver.driver, Constants.EXPLICIT_WAIT_HIGH);
			wb.until(ExpectedConditions.elementToBeClickable(element));
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	public static void closeTheDriver(){
		Driver.driver.quit();
	}
	
	public static String getTitle(){
		return Driver.driver.getTitle();
	}
	
	public static String getCurrentURL(){
		return Driver.driver.getCurrentUrl();
	}
	
	public static void normalWait(int timeInMilli){
		try{
				Thread.sleep(timeInMilli);
			
		}catch(InterruptedException e){
			
		}
		
	}
	
	public static void selectListWithVisibleText(WebElement wb, String textToSelect){
		Select select=new Select(wb);
		select.selectByVisibleText(textToSelect);
		normalWait(1000);
	}
	
	public static void selectListWithIndex(WebElement wb, int indexToSelect){
		Select select=new Select(wb);
		select.selectByIndex(indexToSelect);
	}
	
	public static void selectListWithValue(WebElement wb, String valueToSelect){
		Select select=new Select(wb);
		select.selectByValue(valueToSelect);
	}
	
	public static WebElement returnWebElement(String xpath){
		return Driver.driver.findElement(By.xpath(xpath));
	}
	public static List<WebElement> returnWebElements(String xpath){
		return Driver.driver.findElements(By.xpath(xpath));
	}
	public static int returnSizeOfElements(String xpath){
		int count = 0;
		try{
			List<WebElement> list = Driver.driver.findElements(By.xpath(xpath));
			count = list.size();
		}catch(Exception e){
			return count;
		}
		return count;
	}
	
	public static boolean visibilityOfElementLocated(String xpath){
		try{
			WebDriverWait wb=new WebDriverWait(Driver.driver, Constants.EXPLICIT_WAIT_HIGH);
			wb.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public static boolean visibilityOfElementLocated(String xpath,int waitTimeInSeconds){
		try{
			WebDriverWait wb=new WebDriverWait(Driver.driver, waitTimeInSeconds);
			wb.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(xpath)));
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public static boolean visibilityOfElementLocated(WebElement element){
		try{
			WebDriverWait wb=new WebDriverWait(Driver.driver, Constants.EXPLICIT_WAIT_HIGH);
			wb.until(ExpectedConditions.visibilityOf(element));
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static boolean visibilityOfElementLocated(WebElement element, int waitTimeInSeconds){
		try{
			WebDriverWait wb=new WebDriverWait(Driver.driver, waitTimeInSeconds);
			wb.until(ExpectedConditions.visibilityOf(element));
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static boolean textToBePresentInElement(WebElement element, String text){
		try{
			WebDriverWait wb=new WebDriverWait(Driver.driver, Constants.EXPLICIT_WAIT_HIGH);
			wb.until(ExpectedConditions.textToBePresentInElement(element, text));
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static String captureScreenshot(String destPath){
		try{
			EventFiringWebDriver edriver=new EventFiringWebDriver(Driver.driver);
			File src=edriver.getScreenshotAs(OutputType.FILE);
			System.out.println("output: " + src.getAbsolutePath());
			File dest=new File(destPath);
			FileUtils.copyFile(src, new File(destPath));
			return destPath;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null ;
	}
	public static Actions actionClass(){
		Actions act=new Actions(Driver.driver);
		return act;
	}
	public static Alert switchToAlert(){
		try{
			return Driver.driver.switchTo().alert();
		}catch(Exception e){
			return null;
		}
	}
	public static boolean isElementPresent(WebElement element) {
		boolean flag = false;
		try {
			if (element.isDisplayed()
					|| element.isEnabled())
				flag = true;
		} catch (NoSuchElementException e) {
			flag = false;
		} catch (StaleElementReferenceException e) {
			flag = false;
		}
		return flag;
	}
	public static void pressEnter(){
		Robot r;
		try {
			r = new Robot();
			r.keyPress(KeyEvent.VK_ENTER);
			r.keyRelease(KeyEvent.VK_ENTER);
		} catch (AWTException e) {
			e.printStackTrace();
		}
		
	}
	public static void browserRefresh(){
		Driver.driver.navigate().refresh();
		implicitWait(120);
	}
	public static void doubleClick(WebElement element) {
		try {
			Actions action = new Actions(Driver.driver).doubleClick(element);
			action.build().perform();

			System.out.println("Double clicked the element");
		} catch (StaleElementReferenceException e) {
			System.out.println("Element is not attached to the page document "
					+ e.getStackTrace());
		} catch (NoSuchElementException e) {
			System.out.println("Element " + element + " was not found in DOM "
					+ e.getStackTrace());
		} catch (Exception e) {
			System.out.println("Element " + element + " was not clickable "
					+ e.getStackTrace());
		}
	}
	public static void javaWait(int time) {
		try{
			if(time==1){
				Thread.sleep(1000);
			}else if (time==2) {
				Thread.sleep(2000);
			}else if (time==3) {
				Thread.sleep(3000);
			}else if (time==4) {
				Thread.sleep(4000);
			}else if (time==5){
				Thread.sleep(5000);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	public static String getText(String xpath){
		String text = null;
		try{
			text = Driver.driver.findElement(By.xpath(xpath)).getText();
		}catch(Exception e){
			return text;
		}
		return text;
	}
	public static boolean scrollPage(){
		try{
			((JavascriptExecutor)Driver.driver).executeScript("javascript:window.scrollBy(0,400)"); 
		    
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public static boolean scrollToWebElement(WebElement wb){
		try{    
		    ((JavascriptExecutor)Driver.driver).executeScript("arguments[0].scrollIntoView();", wb);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	public static boolean ClickOnElementUsingJS(WebElement wb){
		try{    
		    ((JavascriptExecutor)Driver.driver).executeScript("arguments[0].click();", wb);
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	
	public static String launchNewBrowserWindow(String url){
		try{
			//String selectLinkOpeninNewTab = Keys.chord(Keys.CONTROL,"t");
			//Driver.driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"n");
			//Actions newTab = new Actions(Driver.driver);
		    //newTab.sendKeys(Keys.CONTROL + "t").perform();
			((JavascriptExecutor)Driver.driver).executeScript("window.open();");
			
			Set<String> windowID = Driver.driver.getWindowHandles();
			
			Iterator<String> it1 = windowID.iterator();
			String parentWin = it1.next();
			String childWin = it1.next();
			Driver.driver.switchTo().window(childWin);
			Driver.driver.navigate().to(url);
			implicitWait(60);
			return parentWin;
			}catch(Exception e){
				return null;
			}
			
	}
	
	public static boolean returnToParentWindow(String parentWindowId){
		
		try{
			Driver.driver.switchTo().window(parentWindowId);
			normalWait(500);
			return true;
		}catch(Exception e){
			return false;
		}
	}
	
	public static boolean closeCurrentBrowserTab(){
		try{
		Driver.driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"w");
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static boolean closeCurrentBrowserWindow(){
		try{
		Driver.driver.close();
		}catch(Exception e){
			return false;
		}
		return true;
	}
	
	public static String returnTodaysDate(){
		DateFormat df = new SimpleDateFormat("MM/dd/yyyy");
		return df.format(new Date());
	}
	
	public static String returnFutureDateStartingTodaysDate(int noOfMonthsToAdd, int noOfDaysToAdd, int noOfYearsToAdd){
		String todaysDate = returnTodaysDate();
		String splitDays[] = todaysDate.split("/");
		int newMM = Integer.parseInt(splitDays[0]) + noOfMonthsToAdd;
		int newDD = Integer.parseInt(splitDays[1]) + noOfDaysToAdd;
		int newYYYY = Integer.parseInt(splitDays[2]) + noOfYearsToAdd;
		String newDate;
		String newMonth;
		if(newDD<10){
			newDate = "0"+newDD;
		}else{
			if(newDD>30){
				newMM++;
				
				if((newDD - 30)<10){
					newDate = "0" + (newDD - 30) +"";
				}else{
					newDate = (newDD - 30) +"";
				}	
			}else{
				newDate = ""+newDD;
			}	
		}
		
		if(newMM<10){
			newMonth = "0"+newMM;
		}else{
			if(newMM>12){
				newYYYY++;
				
				if((newMM - 12)<10){
					newMonth = "0" + (newMM - 12) +"";
				}else{
					newMonth = (newMM - 12) +"";
				}	
			}else{
				newMonth = ""+newMM;
			}
			
		}
		
		return newMonth+"/"+newDate+"/"+newYYYY;
	}

}
