package com.test.edulearningcurve.elcui.impl.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.test.edulearningcurve.utils.Driver;

public class ELCHomePage {
Logger logger;
	
	public ELCHomePage(){
		logger = Logger.getLogger(this.getClass());
	}

	public static ELCHomePage getInstance(){
		return PageFactory.initElements(Driver.driver, ELCHomePage.class);
	}
	
	@FindBy(xpath = "//a[@class='logo']")
	private WebElement ELCHomePageHeaderElement;
	
	@FindBy(id = "login_top")
	private WebElement ELCHomePageLoginButton;
	
	@FindBy(id = "apply")
	private WebElement ELCHomePageSignupButton;
	
	@FindBy(xpath = "//*[@id='copy_right']/div[1]")
	private WebElement ELCHomePageCopyrightText;
	
	@FindBy(xpath = "//*[@id='copy_right']/div[2]")
	private WebElement ELCHomePageDesignText;
	
	@FindBy(xpath = ".//*[@id='follow_us']//a/i[@class='icon-facebook']")
	private WebElement ELCHomePagefollowfacebook;
	
	@FindBy(xpath = "//*[@id='copy_right']/div[2]")
	private WebElement ELCHomePagefollowTwitter;
	/**
	 * Methods
	 */
	public boolean validateELCHomePage(){
		try{
			System.out.println(Driver.driver.getTitle());
			Assert.assertTrue(Driver.driver.getTitle().contains("Learning Curve"), "Not validated the Home page title.");
			logger.info("ELC home page title validated successfully.");
			
			Assert.assertTrue(ELCHomePageHeaderElement.getText().equalsIgnoreCase("Learning curve"), "Not validated the Home page Header.");
			logger.info("ELC home page Header validated successfully.");
			
			Assert.assertTrue(ELCHomePageLoginButton.isDisplayed(), "Not Visible Login Button.");
			logger.info("ELC home page Login Button visible.");
			
			Assert.assertTrue(ELCHomePageSignupButton.isDisplayed(), "Not Visible Signup Button.");
			logger.info("ELC home page Signup Button visible.");
			
//			Assert.assertTrue(ELCHomePageCopyrightText.getText().equals(" � 2017 All Rights Reserved "), "Copy right text not verified");
//			logger.info("ELC home page Copy right text verified.");
//			
//			Assert.assertTrue(ELCHomePageCopyrightText.getText().contains("Design and Developed by Amerytech Networks Pvt Ltd"), "Company name text not verified");
//			logger.info("ELC home page Company name text verified.");
//			
			Assert.assertTrue(ELCHomePagefollowfacebook.isDisplayed(), "Not Visible facebook follow up Button.");
			logger.info("ELC home page facebook follow up  Button visible.");
			
			Assert.assertTrue(ELCHomePagefollowTwitter.isDisplayed(), "Not Visible twitter followup Button.");
			logger.info("ELC home page twitter followup Button visible.");
		}catch(Exception e){
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
}
