package javaInterviewQuestion;

public class OddOrEven {

	public static void main(String[] args) {
		
		int x=10;
		
		if ( x % 2 == 0 )
	         System.out.println("You entered an even number.");
	      else
	         System.out.println("You entered an odd number.");
	   

	}

}
