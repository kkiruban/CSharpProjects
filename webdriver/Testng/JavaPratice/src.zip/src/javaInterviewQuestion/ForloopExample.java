package javaInterviewQuestion;

public class ForloopExample {

	public static void main(String[] args) {
		
//		for(initialization;condition;incr/decr){  
//			//code to be executed  
//			}  
		
		for(int i=1;i<=10;i++){  
	        System.out.println(i);  
	    }  

	}

}
