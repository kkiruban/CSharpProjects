package javaInterviewQuestion;

public class ReplaceString {

	public static void main(String[] args) {
		
		String str = "I use selenium webdriver. selenium is a tool for web applications automation.";
		
		System.out.println(str.replaceAll("selenium", "firefox"));

	}

}
