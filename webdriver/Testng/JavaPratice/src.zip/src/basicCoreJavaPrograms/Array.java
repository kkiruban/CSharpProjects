package basicCoreJavaPrograms;

public class Array {

	public static void main(String[] args) {
		
		
		int[] arrayone = new int[5];
		
		  arrayone[0]=2;
		  arrayone[1]=4;
		  arrayone[2]=6;
		  arrayone[3]=8;
		  System.out.println(arrayone[3]);
		  

	}

}
