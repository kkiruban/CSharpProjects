package CodeCrackingforJava;

public class LengthOfString {

	public static void main(String[] args) {
		
		
		String str="holy cross matriculation higher secondary school";
		
		 int lengthofstring =str.length();
		 
		 System.out.println(lengthofstring);

	}

}
