package CodeCrackingforJava;

public class ConcatenateString {

	public static void main(String[] args) {
		
		
		String str1 = "kirub";
		String str2 = "anand";
		String str3= "";
		
		str3= str1.concat(str2);
		
		System.out.println(str3);
		

	}

}
