package CodeCrackingforJava;

public class printString {

	public static void main(String[] args) {
		
		
		String str="kiruba the great";
		
		System.out.println(str);
				

	}

}
