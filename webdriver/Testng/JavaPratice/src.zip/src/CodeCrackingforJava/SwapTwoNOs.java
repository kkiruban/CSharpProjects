package CodeCrackingforJava;

public class SwapTwoNOs {

	public static void main(String[] args) {
		int a,b,temp;
		
		a=10;
		b=20;
		
		temp=a;
		a=b;
		b=temp;
		
System.out.print("The Value of the First and Second Number after Swapping is \n");
		
        System.out.print("First Number = " +a);
        System.out.print("\nSecond Number = " +b);

	}

}
