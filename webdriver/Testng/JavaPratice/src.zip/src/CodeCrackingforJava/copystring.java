package CodeCrackingforJava;

public class copystring {

	public static void main(String[] args) {
		
		
		String str= "kirubanand";
		
		StringBuffer strcpoy= new StringBuffer(str);
		System.out.println(strcpoy);

	}

}
